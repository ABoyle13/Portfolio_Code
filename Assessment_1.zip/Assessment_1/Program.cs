﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Assessment_1
{
    class Program
    {
        static void Main(string[] args)
        {
            while(true)
            {
                string[] file = Menu();
                int n = file.Length;

                Console.WriteLine("How would you like to sort your chosen array?");
                Console.WriteLine("1 - Bubble sort (ascending order)");
                Console.WriteLine("2 - Bubble sort (descending order)");
                Console.WriteLine("3 - Insertion sort (ascending order)");
                Console.WriteLine("4 - Insertion sort (descending order)");
                Console.WriteLine("5 - Cocktail Shaker sort (ascending order)");
                Console.WriteLine("6 - Cocktail Shaker sort (descending order)");
                Console.WriteLine("7 - Merge sort (ascending order)");
                Console.WriteLine("8 - Merge sort (descending order)\n");

                int choice = 0;
                try
                {
                    choice = Convert.ToInt32(Console.ReadLine());
                    if (choice < 1 || choice > 8)
                    {
                        Console.WriteLine("Please enter a valid input.\n");
                        continue;
                    }
                }
                catch (FormatException)
                {
                    Console.WriteLine("Please enter a valid input.\n");
                }
                catch (OverflowException)
                {
                    Console.WriteLine("Please enter a valid input.\n");
                }
                Console.WriteLine();

                string[] sorted_array = new string[n];
                double count = 0.0;
                switch(choice)
                {
                    case 1:
                        sorted_array = Bubble_Asc(file, n);
                        break;
                    case 2:
                        sorted_array = Bubble_Dsc(file, n);
                        break;
                    case 3:
                        sorted_array = Insertion_Asc(file, n);
                        break;
                    case 4:
                        sorted_array = Insertion_Dsc(file, n);
                        break;
                    case 5:
                        sorted_array = Cocktail_Asc(file, n);
                        break;
                    case 6:
                        sorted_array = Cocktail_Dsc(file, n);
                        break;
                    case 7:
                        count = n * Math.Log(Convert.ToDouble(n), 2);
                        sorted_array = MergeSort_Asc(file, n);
                        Console.WriteLine("Array sorted into ascending order.");
                        Console.WriteLine($"Sorting took {count} steps.\n");
                        Console.WriteLine("Below shows every 10th value of the sorted array.\n");
                        break;
                    case 8:
                        count = n * Math.Log(Convert.ToDouble(n), 2);
                        sorted_array = MergeSort_Dsc(file, n);
                        Console.WriteLine("Array sorted into descending order.");
                        Console.WriteLine($"Sorting took {count} steps.\n");
                        Console.WriteLine("Below shows every 10th value of the sorted array.\n");
                        break;
                }
                if (n <= 1000)
                {
                    for (int a = 0; a < n; a += 10)
                    {
                        Console.WriteLine(sorted_array[a]);
                    }
                    Console.WriteLine();
                }
                else
                {
                    for (int a = 0; a < n; a += 50)
                    {
                        Console.WriteLine(sorted_array[a]);
                    }
                    Console.WriteLine();
                }

                Console.WriteLine("How would you like to search this array?");
                Console.WriteLine("1 - Linear Search");
                Console.WriteLine("2 - Binary Search");
                int answer = 0;
                try
                {
                    answer = Convert.ToInt32(Console.ReadLine());
                    if (answer < 1 || answer > 2)
                    {
                        Console.WriteLine("Please enter a valid input.\n");
                        continue;
                    }
                }
                catch (FormatException)
                {
                    Console.WriteLine("Please enter a valid input.\n");
                }
                catch (OverflowException)
                {
                    Console.WriteLine("Please enter a valid input.\n");
                }

                if (answer == 1)
                {
                    Console.WriteLine();
                    Console.WriteLine("Enter the value you wish to search for:");
                    int num = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine();
                    int[] values = Linear(sorted_array, num, n);
                    if (values[0] >= 0)
                    {
                        if (values[1] != 0)
                        {
                            Console.WriteLine($"The location of {num} in the array is position {values[0]} and {values[1]}.");
                            Console.WriteLine("\n");
                        }
                        else
                        {
                            Console.WriteLine($"The location of {num} in the array is position {values[2]}.");
                        }
                        Console.WriteLine($"This search took {values[2]} steps.");
                        Console.WriteLine("\n");
                    }
                    else
                    {
                        Console.WriteLine("This value does not exist in this array.");
                        Console.WriteLine();
                        int[] items = Find_Value(sorted_array, num);
                        Console.WriteLine($"The nearest value to your value is: {items[0]} and its index position is: {items[1]}.");
                        Console.WriteLine();
                    }
                }
                    
                else if (answer == 2)
                {
                    Console.WriteLine();
                    Console.WriteLine("Enter the value you wish to search for:");
                    int num = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine();
                    int[] values = Binary(sorted_array, num, n);
                    if (values[0] >= 0)
                    {
                        if (values[4] > 0)
                        {
                            Console.WriteLine($"The location of {num} in the array is position {values[0]} and {values[4]}");
                        }
                        else
                        {
                            Console.WriteLine($"The location of {num} in the array is position {values[0]}.");
                        }
                        Console.WriteLine($"This search took {values[3]} steps.");
                        Console.WriteLine("\n");
                    }
                    else
                    {
                        Console.WriteLine("This value does not exist in this array.");
                        Console.WriteLine();
                        Console.WriteLine($"The nearest value to your value is: {values[2]} and its index position is: {values[1]}.");
                        Console.WriteLine();
                    }
                }
                
            }
        }

        static string[] Menu()
        {
            int answer = 0;
            while(true)
            { 
                Console.WriteLine("Welcome to the Sorting program.");
                Console.WriteLine();
                Console.WriteLine("Which array would you like to sort?");
                Console.WriteLine("1 - File 1 of length 256");
                Console.WriteLine("2 - File 2 of length 256");
                Console.WriteLine("3 - File 3 of length 256");
                Console.WriteLine("4 - File 1 of length 2048");
                Console.WriteLine("5 - File 2 of length 2048");
                Console.WriteLine("6 - File 3 of length 2048");
                Console.WriteLine("7 - Both File 1 (length 256) and File 3 (length 256) merged together");
                Console.WriteLine("8 - Both File 1 (length 2048) and File 3 (length 2048) merged together");
                Console.WriteLine();
                Console.WriteLine("9 - Quit");
                try
                {
                    answer = Convert.ToInt32(Console.ReadLine());
                    if (answer < 1 || answer > 9)
                    {
                        Console.WriteLine("Please enter a valid input.\n");
                        continue;
                    }
                    break;
                }
                catch (FormatException)
                {
                    Console.WriteLine("Please enter a valid input.\n");
                }
                catch(OverflowException)
                {
                    Console.WriteLine("Please enter a valid input.\n");
                }
            }

            try 
            {
                switch (answer)
                {
                    case 1:
                        string[] file1 = System.IO.File.ReadAllLines(@"Net_1_256.txt");
                        return file1;
                    case 2:
                        string[] file2 = System.IO.File.ReadAllLines(@"Net_2_256.txt");
                        return file2;
                    case 3:
                        string[] file3 = System.IO.File.ReadAllLines(@"Net_3_256.txt");
                        return file3;
                    case 4:
                        string[] file1B = System.IO.File.ReadAllLines(@"Net_1_2048.txt");
                        return file1B;
                    case 5:
                        string[] file2B = System.IO.File.ReadAllLines(@"Net_2_2048.txt");
                        return file2B;
                    case 6:
                        string[] file3B = System.IO.File.ReadAllLines(@"Net_3_2048.txt");
                        return file3B;
                    case 7:
                        string[] file1A = System.IO.File.ReadAllLines(@"Net_1_256.txt");
                        string[] file3A = System.IO.File.ReadAllLines(@"Net_3_256.txt");
                        string[] file1_3 = new string[512];
                        file1A.CopyTo(file1_3, 0);
                        file3A.CopyTo(file1_3, 256);
                        return file1_3;
                    case 8:
                        string[] file1B_ = System.IO.File.ReadAllLines(@"Net_1_2048.txt");
                        string[] file3B_ = System.IO.File.ReadAllLines(@"Net_3_2048.txt");
                        string[] file1_3_B = new string[4096];
                        file1B_.CopyTo(file1_3_B, 0);
                        file3B_.CopyTo(file1_3_B, 2048);
                        return file1_3_B;
                    case 9:
                        Environment.Exit(0);
                        string[] exit = new string[0];
                        return exit;
                    default:
                        return null;
                }
            }
            catch (FileNotFoundException)
            {
                Console.WriteLine("File does not exist");
                Console.WriteLine();
                Environment.Exit(0);
                string[] no = new string[0];
                return no;
            }
        }

        static string[] Bubble_Asc(string[] info, int n)
        {
            int count = 0;
            for (int i = 0; i < n - 1; i++)
            {
                for (int j = 0; j < n - i - 1; j++)
                {
                    count++;
                    if (Convert.ToInt32(info[j+1]) < Convert.ToInt32(info[j]))
                    {
                        int temp = Convert.ToInt32(info[j]);
                        info[j] = info[j + 1];
                        info[j + 1] = Convert.ToString(temp);
                    }
                }
            }
            Console.WriteLine("Array sorted into ascending order.");
            Console.WriteLine($"Sorting took {count} steps.\n");
            Console.WriteLine("Below shows every 10th value of the sorted array.\n");
            Console.WriteLine(info[60]);

            return info;
        }

        static string[] Bubble_Dsc(string[] info, int n)
        {
            int count = 0;
            for (int i = 0; i < n - 1; i++)
            {
                for (int j = 0; j < n - i - 1; j++)
                {
                    count++;
                    if (Convert.ToInt32(info[j + 1]) > Convert.ToInt32(info[j]))
                    {
                        int temp = Convert.ToInt32(info[j]);
                        info[j] = info[j + 1];
                        info[j + 1] = Convert.ToString(temp);
                    }
                }
            }
            Console.WriteLine("Array sorted into descending order.");
            Console.WriteLine($"Sorting took {count} steps.\n");
            Console.WriteLine("Below shows every 10th value of the sorted array.\n");

            return info;
        }

        static string[] Insertion_Asc(string[] info, int n)
        {
            int count = 0;
            for (int i = 0; i < n - 1; i++)
            {
                int v = Convert.ToInt32(info[i]);
                int j = i - 1;
                while (j >= 0 && Convert.ToInt32(info[j]) > v)
                {
                    count++;
                    info[j + 1] = info[j];
                    j = j - 1;
                }
                info[j + 1] = Convert.ToString(v);
            }
            Console.WriteLine("Array sorted into ascending order.");
            Console.WriteLine($"Sorting took {count} steps.\n");
            Console.WriteLine("Below shows every 10th value of the sorted array.\n");

            return info;
        }

        static string[] Insertion_Dsc(string[] info, int n)
        {
            int count = 0;
            for (int i = 0; i < n - 1; i++)
            {
                int v = Convert.ToInt32(info[i]);
                int j = i - 1;
                while (j >= 0 && Convert.ToInt32(info[j]) < v)
                {
                    count++;
                    info[j + 1] = info[j];
                    j = j - 1;
                }
                info[j + 1] = Convert.ToString(v);
            }
            Console.WriteLine("Array sorted into ascending order.");
            Console.WriteLine($"Sorting took {count} steps.\n");
            Console.WriteLine("Below shows every 10th value of the sorted array.\n");

            return info;
        }

        static string[] Cocktail_Asc(string[] info, int n)
        {
            int count = 0;
            bool swapped = true;
            int start = 0;
            int end = n - 1;
            while (swapped)
            {
                swapped = false;
                for (int i = start; i < end - 1; i++)
                {
                    if (Convert.ToInt32(info[i + 1]) < Convert.ToInt32(info[i]))
                    {
                        int temp = Convert.ToInt32(info[i]);
                        info[i] = info[i + 1];
                        info[i + 1] = Convert.ToString(temp);
                        swapped = true;
                        count++;
                    }
                }

                if (swapped == false)
                {
                    break;
                }

                swapped = false;
                end--;

                for (int j = end - 1; j >= start; j--)
                {
                    if (Convert.ToInt32(info[j]) > Convert.ToInt32(info[j + 1]))
                    {
                        int temp = Convert.ToInt32(info[j]);
                        info[j] = info[j + 1];
                        info[j + 1] = Convert.ToString(temp);
                        swapped = true;
                        count++;
                    }
                }
                start++;
            }
            
            Console.WriteLine("Array sorted into ascending order.");
            Console.WriteLine($"Sorting took {count} steps.\n");
            Console.WriteLine("Below shows every 10th value of the sorted array.\n");
            return info;
        }

        static string[] Cocktail_Dsc(string[] info, int n)
        {
            int count = 0;
            bool swapped = true;
            int start = 0;
            int end = n - 1;
            while (swapped)
            {
                swapped = false;
                for (int i = start; i < end - 1; i++)
                {
                    if (Convert.ToInt32(info[i + 1]) > Convert.ToInt32(info[i]))
                    {
                        int temp = Convert.ToInt32(info[i]);
                        info[i] = info[i + 1];
                        info[i + 1] = Convert.ToString(temp);
                        swapped = true;
                        count++;
                    }
                }

                if (swapped == false)
                {
                    break;
                }

                swapped = false;
                end--;

                for (int j = end - 1; j >= start; j--)
                {
                    if (Convert.ToInt32(info[j]) < Convert.ToInt32(info[j + 1]))
                    {
                        int temp = Convert.ToInt32(info[j]);
                        info[j] = info[j + 1];
                        info[j + 1] = Convert.ToString(temp);
                        swapped = true;
                        count++;
                    }
                }
                start++;
            }

            Console.WriteLine("Array sorted into ascending order.");
            Console.WriteLine($"Sorting took {count} steps.\n");
            Console.WriteLine("Below shows every 10th value of the sorted array.\n");
            return info;
        }

        static string[] Merge_Asc(string[] left, string[] right, int n)
        {
            string[] merged = new string[n];
            int count_left = 0;
            int count_right = 0;
            int count_merged = 0;
            while ((count_left < left.Length) && (count_right < right.Length))
            {
                if (Convert.ToInt32(left[count_left]) < Convert.ToInt32(right[count_right]))
                {
                    merged[count_merged] = left[count_left];
                    count_left++;
                }
                else
                {
                    merged[count_merged] = right[count_right];
                    count_right++;
                }
                count_merged++;
            }
            while (count_left < left.Length)
            {
                merged[count_merged] = left[count_left];
                count_left++;
                count_merged++;
            }
            while (count_right < right.Length)
            {
                merged[count_merged] = right[count_right];
                count_right++;
                count_merged++;
            }
            return merged;
        }

        static string[] MergeSort_Asc(string[] info, int n)
        {
            if (n > 1)
            {
                int mid = n / 2;
                string[] right = new string[mid];
                string[] left = new string[mid];
                
                int num = 0;
                int num2 = 0;
                for (int i = 0; i < n; i++)
                {
                    if (i < mid)
                    {
                        left[num] = info[i];
                        num++;
                    }
                    else
                    {
                        right[num2] = info[i];
                        num2++;
                    }
                }
                string[] merged = Merge_Asc(MergeSort_Asc(left, mid), MergeSort_Asc(right, mid), n);
                return merged;
            }
            else
            {
                return info;
            }
        }

        static string[] Merge_Dsc(string[] left, string[] right, int n)
        {
            string[] merged = new string[n];
            int count_left = 0;
            int count_right = 0;
            int count_merged = 0;
            while ((count_left < left.Length) && (count_right < right.Length))
            {
                if (Convert.ToInt32(left[count_left]) > Convert.ToInt32(right[count_right]))
                {
                    merged[count_merged] = left[count_left];
                    count_left++;
                }
                else
                {
                    merged[count_merged] = right[count_right];
                    count_right++;
                }
                count_merged++;
            }
            while (count_left < left.Length)
            {
                merged[count_merged] = left[count_left];
                count_left++;
                count_merged++;
            }
            while (count_right < right.Length)
            {
                merged[count_merged] = right[count_right];
                count_right++;
                count_merged++;
            }
            return merged;
        }

        static string[] MergeSort_Dsc(string[] info, int n)
        {
            if (n > 1)
            {
                int mid = n / 2;
                string[] right = new string[mid];
                string[] left = new string[mid];

                int num = 0;
                int num2 = 0;
                for (int i = 0; i < n; i++)
                {
                    if (i < mid)
                    {
                        left[num] = info[i];
                        num++;
                    }
                    else
                    {
                        right[num2] = info[i];
                        num2++;
                    }
                }
                return Merge_Dsc(MergeSort_Dsc(left, mid), MergeSort_Dsc(right, mid), n);
            }
            else
            {
                return info;
            }
        }

        static int[] Linear(string[] sorted_array, int num, int n)
        {
            int[] info = new int[3];
            int step = 0;
            for (int i = 0; i < n; i++)
            {
                step++;
                if (Convert.ToInt32(sorted_array[i]) == num)
                {
                    info[0] = i;
                    int count = 1;
                    if (sorted_array[i] == sorted_array[i + 1])
                    {
                        info[count] = i + 1;
                        i++;
                    }
                    info[2] = step;
                    return info;
                }
            }
            info[0] = -1;
            return info;
        }

        static int[] Find_Value(string[] sorted_array, int value)
        {
            int diff = 1000000000;
            int[] items = new int[3];
            int index = -1;
            foreach (string item in sorted_array)
            {
                index++;
                int new_diff = Math.Abs(value - Convert.ToInt32(item));
                if (new_diff < diff)
                {
                    diff = new_diff;
                }
                else
                {
                    index--;
                    items[0] = Convert.ToInt32(sorted_array[index]);
                    items[1] = index;
                    return items;
                }
            }
            return items;
        }

        static int[] Binary(string[] sorted_array, int value, int n)
        {
            int count = 0;
            int start = 0;
            int end = n - 1;
            int mid = 0;
            int[] items = new int[5];
            while (start <= end)
            {
                mid = start + ((end - start) / 2);
                if (Convert.ToInt32(sorted_array[mid]) == value)
                {
                    items[0] = mid;
                    if (sorted_array[mid + 1] == sorted_array[mid])
                    {
                        items[4] = mid + 1;
                    }
                    count++;
                    items[3] = count;
                    foreach (int item in items)
                    {
                        Console.WriteLine(item);
                    }
                    return items;
                }
                else if (Convert.ToInt32(sorted_array[mid]) < value)
                {
                    start = mid + 1;
                    count++;
                }
                else if (Convert.ToInt32(sorted_array[mid]) > value)
                {
                    end = mid - 1;
                    count++;
                }
            }
            items[0] = -1;
            int near = value - Convert.ToInt32(sorted_array[mid]);
            if ((Convert.ToInt32(sorted_array[mid + 1]) < near))
            {
                int index = mid + 1;
                items[1] = index;
                items[2] = Convert.ToInt32(sorted_array[index]);
            }
            else if ((Convert.ToInt32(sorted_array[mid - 1]) < near))
            {
                int index = mid - 1;
                items[1] = index;
                items[2] = Convert.ToInt32(sorted_array[index]);
            }
            else
            {
                items[1] = mid;
                items[2] = Convert.ToInt32(sorted_array[mid]);
            }
            return items;
        }
    }
}
